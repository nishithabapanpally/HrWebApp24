package com.myhr.dev.empapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpappApplicationTests {

	@Test
	void contextLoads() {
	}

}
